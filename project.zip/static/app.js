document.addEventListener('DOMContentLoaded', () => {
    // Инициализация состояния
    let state = {
        tasks: [],
        groups: [],
        currentDate: new Date(),
        theme: localStorage.getItem('theme') || 'light',
        autoTheme: localStorage.getItem('autoTheme') === 'true',
        counters: [] // Add counters to the state
    };

    // Добавим функцию форматирования даты
    function formatDate(date) {
        const day = date.getDate().toString().padStart(2, '0');
        const month = (date.getMonth() + 1).toString().padStart(2, '0');
        const year = date.getFullYear().toString().slice(-2);
        return `${day}.${month}.${year}`;
    }

    // Обновим инициализацию flatpickr
    const datePicker = flatpickr("#date-picker", {
        dateFormat: "d.m.y",
        defaultDate: state.currentDate,
        onChange: (selectedDates) => {
            state.currentDate = selectedDates[0];
            updateDateDisplay();
            loadTasks();
            updateDateButtons();
        }
    });

    // Добавим функцию обновления отображения даты
    function updateDateDisplay() {
        const dateDisplay = document.getElementById('current-date');
        if (dateDisplay) {
            dateDisplay.textContent = formatDate(state.currentDate);
        }
    }

    flatpickr("#time-start", {
        enableTime: true,
        noCalendar: true,
        dateFormat: "H:i",
        time_24hr: true
    });

    flatpickr("#time-end", {
        enableTime: true,
        noCalendar: true,
        dateFormat: "H:i",
        time_24hr: true
    });

    // Обработка темы
    function updateTheme() {
        if (state.autoTheme) {
            const hour = new Date().getHours();
            state.theme = (hour >= 6 && hour < 18) ? 'light' : 'dark';
        }
        document.body.className = `${state.theme}-theme`;
        localStorage.setItem('theme', state.theme);
    }

    // Обработчики меню
    document.getElementById('menu-button').addEventListener('click', () => {
        document.getElementById('side-menu').classList.add('open');
    });

    document.getElementById('close-menu').addEventListener('click', () => {
        document.getElementById('side-menu').classList.remove('open');
    });

    // Переключение темы
    document.getElementById('theme-toggle').addEventListener('change', (e) => {
        state.theme = e.target.checked ? 'dark' : 'light';
        updateTheme();
    });

    document.getElementById('auto-theme-toggle').addEventListener('change', (e) => {
        state.autoTheme = e.target.checked;
        localStorage.setItem('autoTheme', state.autoTheme);
        if (state.autoTheme) updateTheme();
    });

    // Обновление работы с группами
    document.getElementById('add-group').addEventListener('click', async () => {
        const nameInput = document.getElementById('group-input');
        const colorInput = document.getElementById('group-color');

        if (nameInput.value.trim()) {
            const response = await fetch('/api/groups', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    name: nameInput.value.trim(),
                    color: colorInput.value
                })
            });

            if (response.ok) {
                nameInput.value = '';
                await loadGroups();
            }
        }
    });


    // Навигация по датам
    document.getElementById('prev-day').addEventListener('click', () => {
        const newDate = new Date(state.currentDate);
        newDate.setDate(newDate.getDate() - 1);
        state.currentDate = newDate;
        datePicker.setDate(newDate);
        loadTasks();
        updateDateButtons();
    });

    document.getElementById('next-day').addEventListener('click', () => {
        const newDate = new Date(state.currentDate);
        newDate.setDate(newDate.getDate() + 1);
        state.currentDate = newDate;
        datePicker.setDate(newDate);
        loadTasks();
        updateDateButtons();
    });

    document.querySelectorAll('.date-buttons button').forEach(button => {
        button.addEventListener('click', () => {
            const date = button.dataset.date;
            const today = new Date();
            today.setHours(0, 0, 0, 0);

            switch (date) {
                case 'yesterday':
                    state.currentDate = new Date(today.setDate(today.getDate() - 1));
                    break;
                case 'today':
                    state.currentDate = new Date(today);
                    break;
                case 'tomorrow':
                    state.currentDate = new Date(today.setDate(today.getDate() + 1));
                    break;
            }
            datePicker.setDate(state.currentDate);
            loadTasks();
            updateDateButtons();
        });
    });

    // Обновление кнопок дат
    function updateDateButtons() {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const currentDate = new Date(state.currentDate);
        currentDate.setHours(0, 0, 0, 0);

        document.querySelectorAll('.date-buttons button').forEach(button => {
            button.classList.remove('active');
            const date = button.dataset.date;

            if (date === 'yesterday' && currentDate.getTime() === today.getTime() - 86400000) {
                button.classList.add('active');
            } else if (date === 'today' && currentDate.getTime() === today.getTime()) {
                button.classList.add('active');
            } else if (date === 'tomorrow' && currentDate.getTime() === today.getTime() + 86400000) {
                button.classList.add('active');
            }
        });
    }

    // Загрузка задач с сервера
    async function loadTasks() {
        const date = state.currentDate.toISOString().split('T')[0];
        const response = await fetch(`/api/tasks?date=${date}`);
        state.tasks = await response.json();
        renderTasks();
    }

    // Загрузка групп с сервера
    async function loadGroups() {
        const response = await fetch('/api/groups');
        state.groups = await response.json();
        updateGroupSelect();
    }

    // Обновление списка групп в селекте
    function updateGroupSelect() {
        const groupSelect = document.getElementById('task-group');
        groupSelect.innerHTML = '<option value="">Без группы</option>';
        state.groups.forEach(group => {
            const option = document.createElement('option');
            option.value = group.id;
            option.textContent = group.name;
            groupSelect.appendChild(option);
        });
    }

    // Отображение задач
    function renderTasks() {
        const timeline = document.getElementById('timeline');
        timeline.innerHTML = '';

        // Группировка по времени
        const timeSlots = {};
        state.tasks.forEach(task => {
            const hour = task.time_start ? task.time_start.split(':')[0] : 'Без времени';
            if (!timeSlots[hour]) timeSlots[hour] = [];
            timeSlots[hour].push(task);
        });

        // Отображение временных слотов
        Object.keys(timeSlots).sort().forEach(hour => {
            const slotDiv = document.createElement('div');
            slotDiv.className = 'time-slot';
            slotDiv.innerHTML = `<h3>${hour === 'Без времени' ? hour : hour + ':00'}</h3>`;

            timeSlots[hour].forEach(task => {
                const taskDiv = document.createElement('div');
                taskDiv.className = `task-item${task.completed ? ' completed' : ''}`;
                const timeRange = task.time_start && task.time_end ?
                    `${task.time_start} — ${task.time_end}` : '';

                taskDiv.innerHTML = `
                    <div class="task-info">
                        <span>${task.text}</span>
                        ${timeRange ? `<span class="time-range">${timeRange}</span>` : ''}
                    </div>
                    <div class="task-controls">
                        <button onclick="toggleTaskComplete(${task.id}, ${!task.completed})">
                            ${task.completed ? '✓' : '○'}
                        </button>
                        <button onclick="deleteTask(${task.id})">×</button>
                    </div>
                `;
                slotDiv.appendChild(taskDiv);
            });

            timeline.appendChild(slotDiv);
        });
    }

    // Обработчики задач
    window.toggleTaskComplete = async (taskId, completed) => {
        const response = await fetch(`/api/tasks/${taskId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ completed })
        });
        if (response.ok) {
            await loadTasks();
        }
    };

    window.deleteTask = async (taskId) => {
        if (confirm('Вы уверены, что хотите удалить эту задачу?')) {
            const response = await fetch(`/api/tasks/${taskId}`, {
                method: 'DELETE'
            });
            if (response.ok) {
                await loadTasks();
            }
        }
    };

    // Добавление новой задачи
    document.getElementById('task-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const taskInput = document.getElementById('task-input');
        const timeStartInput = document.getElementById('time-start');
        const timeEndInput = document.getElementById('time-end');
        const groupSelect = document.getElementById('task-group');

        const task = {
            text: taskInput.value,
            time_start: timeStartInput.value || null,
            time_end: timeEndInput.value || null,
            date: state.currentDate.toISOString().split('T')[0],
            group_id: groupSelect.value || null
        };

        const response = await fetch('/api/tasks', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(task)
        });

        if (response.ok) {
            taskInput.value = '';
            timeStartInput.value = '';
            timeEndInput.value = '';
            await loadTasks();
        }
    });


    // Инициализация
    updateTheme();
    loadGroups();
    loadTasks();
    updateDateButtons();
    updateDateDisplay(); // Initial date display


    // Автоматическое обновление темы
    if (state.autoTheme) {
        setInterval(updateTheme, 60000);
    }

    // Добавим функции для работы со счетчиком трезвости
    function updateCountersList() {
        const countersList = document.getElementById('counters-list');
        countersList.innerHTML = '';
        state.counters.forEach((counter, index) => {
            const days = Math.floor((new Date() - new Date(counter.startDate)) / (1000 * 60 * 60 * 24));
            const counterDiv = document.createElement('div');
            counterDiv.className = 'counter-item';
            counterDiv.style.borderLeft = `3px solid ${counter.color}`;
            counterDiv.innerHTML = `
                <span>${counter.name}</span>
                <div class="counter-controls">
                    <span class="days-count">${days} дней</span>
                    <input type="color" value="${counter.color}" 
                        onchange="updateCounterColor(${index}, this.value)">
                    <button onclick="editCounter(${index})">✎</button>
                    <button onclick="resetCounter(${index})">↺</button>
                    <button onclick="deleteCounter(${index})">×</button>
                </div>
            `;
            countersList.appendChild(counterDiv);
        });
    }

    // Placeholder functions -  You'll need to implement these based on your backend
    window.updateCounterColor = (index, color) => {
        state.counters[index].color = color;
        updateCountersList();
    };
    window.editCounter = (index) => {
        // Implement edit functionality
        console.log("Edit counter", index);
    };
    window.resetCounter = (index) => {
        // Implement reset functionality
        console.log("Reset counter", index);
    };
    window.deleteCounter = (index) => {
        // Implement delete functionality
        state.counters.splice(index, 1);
        updateCountersList();
    };


});